create
    definer = root@localhost procedure proc_insert_dictionary(IN img_url_insert varchar(255),
                                                              IN vocabulary_insert varchar(255),
                                                              IN desc_insert varchar(255))
begin
    insert into dictionary(img_url, vocabulary, `desc`)
        values (img_url_insert, vocabulary_insert, desc_insert);
end;

