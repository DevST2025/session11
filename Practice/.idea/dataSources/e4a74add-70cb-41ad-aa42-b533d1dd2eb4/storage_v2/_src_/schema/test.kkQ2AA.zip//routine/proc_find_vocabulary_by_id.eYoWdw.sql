create
    definer = root@localhost procedure proc_find_vocabulary_by_id(IN idFind int)
begin
    select * from dictionary where id = idFind;
end;

