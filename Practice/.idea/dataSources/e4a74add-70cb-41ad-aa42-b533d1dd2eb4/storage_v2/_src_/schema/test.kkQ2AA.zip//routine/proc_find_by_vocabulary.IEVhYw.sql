create
    definer = root@localhost procedure proc_find_by_vocabulary(IN vocabulary_find varchar(255))
begin
    select * from dictionary where vocabulary like vocabulary_find;
end;

